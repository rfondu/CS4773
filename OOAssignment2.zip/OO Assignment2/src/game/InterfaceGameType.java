package game;

import java.util.ArrayList;

import player.Player;
/**
 * This class is an Interface. Functionality is similar for two and three player
 *  variations of the game. 
 * 
 */
public interface InterfaceGameType {
	
	public void startRound (ArrayList<Player> players, int gameType);
	public void playCards();
	public void compareCards();
	public void nextRoundSetup();
	public void roundWinner();
	public void endRound(int player);
	public Player getWinner();
	public void setWinner(Player player);
}
