package player;

import java.util.ArrayList;

import deck.Card;
/**
 * This class is for the Player object. It contains the player name 
 * and the downPile for each player.
 * 
 */
public class Player {
	
	private String name;
	protected ArrayList<Card> downPile = new ArrayList<Card>();
	
	public Player(String name){
		this.setName(name);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Card> getDownPile() {
		return downPile;
	}
	/**
	 * Output score information for all players 
	 * 
	 * @param players Array list of players
	 */
	public void addCard(Card card) {
		this.downPile.add(card);
	}
	/**
	 * Output score information for all players 
	 * 
	 * @param players Array list of players
	 */
	public Card drawCard() {
		return downPile.remove(0);
	}
	
	public void setDownPile(ArrayList<Card> downpile) {
		this.downPile = downpile;
	}
	
}
