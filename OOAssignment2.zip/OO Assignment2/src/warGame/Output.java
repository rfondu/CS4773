package warGame;

import java.util.ArrayList;

import deck.Card;
import player.Player;
import player.PlayerPoints;

/**
 * This class prints out all the output to the console.
 * 
 */
public class Output {
	
	/**
	 * Output welcome message 
	 */
	public static void introductionPrint(){
		System.out.println("Welcome to\n");
		System.out.println("*************");
		System.out.println("* War Game! *");
		System.out.println("*************\n");	
	}
	/**
	 * Output options to select game type
	 */
	public static void gameTypeChoicesPrint(){
    	System.out.println("Select War Game Variation: \n");
		System.out.println("1) 2 Players - Won Cards Go Back to Winning Players Deck.  Game Ends After a Set Number of Turns.");
		System.out.println("2) 2 Players - Won Cards Go to Winning Players Points Pile.  Game Ends After All Cards Played Once.");
		System.out.println("3) 3 Players - Won Cards Go to Winning Players Points Pile.  Game Ends After All Cards Played Once.");
	}
	/**
	 * Output message if input incorrect
	 */
	public static void selectionErrorPrint(){
		System.out.println("You must enter a number 1-3");		
	}
	/**
	 * Output information of cards played by players in a round
	 * 
	 * @param players Array list of players
	 *        inPlay  Array list of cards in play
	 */
	public static void playedCardPrint(ArrayList<Player> players, ArrayList<Card> inPlay){
		int lastCardPlayed = inPlay.size();
		for (int i = 0, j = players.size(); i < players.size(); i++, j--) {
			System.out.println(players.get(i).getName() + " plays " + inPlay.get(lastCardPlayed-j).getValue() + " of " + inPlay.get(lastCardPlayed-j).getSuit() + " as up card ");
		}
	}
	/**
	 * Output score information for all players 
	 * 
	 * @param players Array list of players
	 */
	public static void printScoreAllPlayers(ArrayList<Player> players, int gameType){
		System.out.print("Score is "); 
		String fencePost = ",";		
		for(Player p: players) {
			if(players.indexOf(p) == players.size()-1){
				fencePost = " ";
			}
			if(gameType == 1){
				System.out.print(p.getName() + " " + p.getDownPile().size() + fencePost + " ");  	
			} else {
				System.out.print(p.getName() + " " + ((PlayerPoints) p).getPoints() + fencePost + " "); 
			}																	
		}
		System.out.println("\n");
	}
	/**
	 * Output welcome message and request input for game type variation to play
	 */
	public static void warPrint(){
		System.out.println("WAR !\n");
	}
	/**
	 * Output name of the round winner
	 * 
	 * @param winnerName String variable of winners name
	 */
	public static void roundWinnerPrint(String winnerName){
		System.out.println(winnerName + " wins the round");
	}
	/**
	 * Output name of the game winner
	 * 
	 * @param winnerName String variable of winners name
	 */
	public static void gameWinnerPrint(String winnerName){	
		System.out.println(winnerName + " wins the game!");
	}
	/**
	 * Output tie game message
	 */
	public static void tieGamePrint(){	
		System.out.println("Tie game!");
	}
}