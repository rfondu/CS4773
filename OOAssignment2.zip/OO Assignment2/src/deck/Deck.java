package deck;

import java.util.ArrayList;
import java.util.Collections;

import player.Player;

/**
 * This class is for the Deck object. It consists of cards in the deck to use in the 
 * play of the game. 
 * 
 */
public class Deck {
	
	private ArrayList<Card> deck = new ArrayList<Card>();
	
	public Deck() {
		deck = new ArrayList<Card>();
	}
	/**
	 * Output information of cards played by players in a round
	 * 
	 * @param deck      Consists of the cards available in the deck
	 *        players   Array list of players
	 */
	public void distributeCardsAmongPlayers(Deck deck, ArrayList<Player> players) {
		int split = deck.getDeck().size() / players.size();
		for(int j = 0; j < players.size(); j++) {
			for(int i = 0; i < split; i++) {
				Card card = deck.getDeck().remove(0);
				players.get(j).addCard(card);
			}
		}
	}
	/**
	 * Add all cards to a Deck. Using the enums to populate the deck.
	 */
	public void fiftyTwoCardDeck(){
		for(SUIT suit: SUIT.values()) {
			for(VALUE value: VALUE.values()) {
				addCardToDeck(new Card(value, suit));				
			}
		}
	}
	/**
	 * Add card to deck
	 */
	public void addCardToDeck(Card card) {	
		deck.add(card);
	}
	/**
	 * Shuffle the deck
	 */
	public void shuffleDeck() {
		Collections.shuffle(deck);
	}
	
	public ArrayList<Card> getDeck() {
		return deck;
	}
}