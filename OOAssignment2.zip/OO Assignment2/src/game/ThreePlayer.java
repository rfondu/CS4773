package game;

import java.util.ArrayList;

import player.Player;

//Same as TwoPlayer but for Tree players. Only override what needs to be overriden
public class ThreePlayer implements InterfaceGameType{

	@Override
	public void roundStart(ArrayList<Player> players) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cardPlayed() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void compareCards() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void roundEnd() {
		// TODO Auto-generated method stub
		
	}

}
