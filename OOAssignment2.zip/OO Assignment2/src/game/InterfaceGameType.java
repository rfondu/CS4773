package game;

import java.util.ArrayList;

import player.Player;

public interface InterfaceGameType {
	
	public void startRound (ArrayList<Player> players);
	public void playCards();
	public void compareCards();
	public void nextRoundSetup();
	public void roundWinner();
	public void endRound(int player);
	public Player getWinner();
	public void setWinner(Player player);
}
