package warGame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import deck.Card;
import deck.Deck;
import game.Continuous;
import game.Points;
import game.ThreePlayer;
import player.Player;
import player.PlayerPoints;
import player.PlayerContinuous;

/**
 * Entry point for program
 * 
 * @authors Tyler Earnest, Gloria Garza, Clint Chenault, and Ryan Fondulis 
 */
public class WarGame {
	
	private static int gameType;
	
	/**
	 * Calls functions to play the game
	 * 
	 * @param args command-line arguments
	 */
	public static void main(String[] args) {
		ArrayList<Player> players = new ArrayList<Player>();
		
		intro();
		Deck deck = new Deck();
		deck.fiftyTwoCardDeck();
		deck.shuffleDeck();
		playerSetup(players);
		distributeCards(deck, players);
		startGame(players);
	}
	/**
	 * Output welcome message and request input for game type variation to play
	 */
	public static void intro() {
		Scanner userInput = new Scanner(System.in);
		Output.introductionPrint();
		
		do {
			Output.gameTypeChoicesPrint();

			if(userInput.hasNextInt())
	    		gameType = userInput.nextInt();
	    	else {
	    		Output.selectionErrorPrint();
	    		userInput.next();
	    	}
		} while (gameType > 3 || gameType < 1);
		userInput.close();
	}
	/**
	 * Start game variation selected
	 */	
	public static void startGame(ArrayList<Player> players) {
		if(gameType == 1) {
			game.InterfaceGameType warTypeOne = new Continuous();
			warTypeOne.startRound(players,gameType);
		}
		if(gameType == 2) {
			game.InterfaceGameType warTypeTwo = new Points();
			warTypeTwo.startRound(players,gameType);
		}
		if(gameType == 3) {
			game.InterfaceGameType warTypeThree = new ThreePlayer();
			warTypeThree.startRound(players,gameType);
		}
	}
	/**
	 * Assign players to player list
	 */
	public static void playerSetup(ArrayList<Player> players) {
		if(gameType == 1){
			PlayerContinuous player1 = new PlayerContinuous("Sue");
			PlayerContinuous player2 = new PlayerContinuous("Bob");
			Collections.addAll(players, player1, player2);
		}
		if(gameType == 2) {
			PlayerPoints player1 = new PlayerPoints("Sue");
			PlayerPoints player2 = new PlayerPoints("Bob");
			Collections.addAll(players, player1, player2);
		}
		if(gameType == 3) {
			PlayerPoints player1 = new PlayerPoints("Sue");
			PlayerPoints player2 = new PlayerPoints("Bob");
			PlayerPoints player3 = new PlayerPoints("Tom");
			Collections.addAll(players, player1, player2, player3);
		}
	}
	/**
	 * Gets deck divides by # players playing then splits the deck to each player
	 */
	public static void distributeCards(Deck deck, ArrayList<Player> players) {
		int cardsPerPlayer = deck.getDeck().size() / players.size();
		for(int j = 0; j < players.size(); j++) {
			for(int i = 0; i < cardsPerPlayer; i++) {
				Card card = deck.getDeck().remove(0);
				players.get(j).addCard(card);
			}
		}
	}
}