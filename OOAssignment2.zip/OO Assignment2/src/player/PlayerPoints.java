package player;
/**
 * This class extends the Player object for game types 2 & 3 variations. Where the cards
 * are placed in a win pile and total # of cards are totaled up at the end of the game to
 * determine the winner or if a tie game.
 * 
 */
public class PlayerPoints extends Player{

	private int totalPoints;
	
	public PlayerPoints(String name) {
		super(name);
	}
	
	public void setPoints(int points){
		totalPoints += points;
	}
	
	public int getPoints() {
		return totalPoints;
	}
}