package deck;

public enum SUIT {SPADES, HEARTS, CLUBS, DIAMONDS}