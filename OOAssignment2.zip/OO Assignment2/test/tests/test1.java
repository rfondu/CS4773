package tests;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import deck.Card;
import deck.Deck;
import deck.SUIT;
import deck.VALUE;
import game.Continuous;
import player.Player;
import player.PlayerContinuous;

public class test1 {

	@Test
	public void nullDeck() {
		Deck deck = new Deck();
		assertEquals(0, deck.getDeck().size());
	}
	
	@Test
	public void fullDeck() {
		Deck deck = new Deck();
		deck.normalDeck();
		assertEquals(52, deck.getDeck().size());
	}
	
	@Test
	public void testSueWinner() {
		Deck deck = new Deck();
		deck.addCardToDeck(new Card(VALUE.ACE, SUIT.HEARTS));
		deck.addCardToDeck(new Card(VALUE.JACK, SUIT.HEARTS));
		
		PlayerContinuous sue = new PlayerContinuous("Sue");
		PlayerContinuous bob = new PlayerContinuous("Bob");
		ArrayList<Player> players = new ArrayList<Player>();
		players.add(sue);
		players.add(bob);
		
		warGame.WarGame.distributeCards(deck, players);
		game.InterfaceGameType war = new Continuous();
		war.roundStart(players);
		
		assertEquals(sue.getName(), war.getWinner().getName());
	}
}