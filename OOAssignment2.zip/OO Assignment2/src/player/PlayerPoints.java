package player;

public class PlayerPoints extends Player{

	private int totalPoints;
	
	public PlayerPoints(String name) {
		super(name);
	}
	
	public void setPoints(int points){
		totalPoints += points;
	}
	
	public int getPoints() {
		return totalPoints;
	}
}