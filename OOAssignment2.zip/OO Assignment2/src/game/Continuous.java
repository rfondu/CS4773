package game;

public class Continuous extends TwoPlayer{
	//Override the Functions that change
}
