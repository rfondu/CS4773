package player;

import java.util.ArrayList;

import deck.Card;
/**
 * This class extends the Player object for game type 1 variation. Where the cards
 * are returned to the players handpile.
 * 
 */
public class PlayerContinuous extends Player{

	public PlayerContinuous(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	/**
	 * Create the downpile for each player in the type 1 variation of the game 
	 * 
	 * @param pile Array list of cards
	 */
	public void addToDownPile(ArrayList<Card> pile){
		ArrayList<Card> TempArray = downPile;
		for(int i = 0; i < pile.size(); i++) {
			TempArray.add(pile.get(i));
		}
		setDownPile(TempArray);
	}
	

}