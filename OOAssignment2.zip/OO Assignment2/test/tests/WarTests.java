package tests;

import org.junit.Test;

import junit.framework.TestCase;

public class WarTests extends TestCase{

	public void setUp()
	{
		
	}

	@Test
	public void test1()
	{
		
	} 
}
