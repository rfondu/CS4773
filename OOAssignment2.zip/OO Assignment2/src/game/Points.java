package game;

public class Points extends TwoPlayer{
	//Override the Functions that change
}
