package game;

import deck.Card;
import player.Player;

public class GameType {

	public void Round (Player player1, Player player2) {
		playCards(player1.drawCard(), player2.drawCard());	
	}
	
	public void playCards(Card player1Card, Card player2Card) {
		warGame.Output.PlayerCard(player1, player1Card);
		warGame.Output.PlayerCard(player2, player2Card);
		// Call Print class to say what cards are being played by players
		CompareCards(player1Card, player2Card);
	}
	
	public void compareCards (Card player1Card, Card player2Card) {		
		if(player1Card.getValue().getCardValue() > player2Card.getValue().getCardValue()) {
			warGame.Output.PlayerWon(player1));
			// Count size of in play array and assign points to player 1 int scoreValue OR player 1 unused hand array
			roundEnd();
		} else if (player1Card.getValue().getCardValue() < player2Card.getValue().getCardValue()) {
			warGame.Output.PlayerWon(player2));
			// Count size of in play array and assign points to player 2 int scoreValue OR player 2 unused hand array
			roundEnd();
		} else {
			warGame.Output.war();
			// Place one down card for each player and call PlayCards() to get another up card for each player
		}
	}

	public void war() {
		// May not need this function
	}
	
	public void roundEnd() {
		warGame.Output.PlayerScore(players);
	}

}