package warGame;

public class Output {

}
