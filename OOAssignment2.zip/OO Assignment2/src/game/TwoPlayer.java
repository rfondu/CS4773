package game;

import java.util.ArrayList;

import deck.Card;
import player.Player;
import warGame.Output;

/**
 * This class implements the InterfaceGameType. This class is for a two player
 * war game. It is further extended to two other classes for the different types
 * of game play. Continuous and Points classes.
 * 
 */
public abstract class TwoPlayer implements InterfaceGameType{
	ArrayList<Card> inPlay = new ArrayList<Card>(); 
	ArrayList<Player> players;
	Player Winner = null;
	int gameType;
	
	/**
	 * Start round of play for list of players.
	 * 
	 * @param players    Array list of players
	 *        gameType   Game type is passed 
	 */
	public void startRound (ArrayList<Player> players, int gameType) {
		this.players = players;
		this.gameType = gameType;
		playCards();	
	}
	/**
	 * Get cards in deck to play hand for each player.
	 */
	public void playCards() {
		if(players.get(0).getDownPile().size() == 0) {
			roundWinner();
			return;
		}
		inPlay.add(players.get(0).drawCard());     			// Player 1 draws a card
		inPlay.add(players.get(1).drawCard());				// Player 2 draws a card
		Output.playedCardPrint(players, inPlay); 	        
		compareCards();										
	}
	/**
	 * Compare the cards drawn for each player
	 */
	public void compareCards() {
		int numberCardPlayed = inPlay.size(); 				
		if(inPlay.get(numberCardPlayed - 2).getValue().getCardValue() > inPlay.get(numberCardPlayed - 1).getValue().getCardValue()) {
			endRound(0);
		} else if (inPlay.get(numberCardPlayed - 2).getValue().getCardValue() < inPlay.get(numberCardPlayed - 1).getValue().getCardValue()) {
			endRound(1);									
		} else {
			war();
		}
	}
	/**
	 * End round of play. Add points to player based on index in parameter.
	 * 
	 * @param player Index of player that won the round
	 */
	public void endRound(int player) {
		Output.roundWinnerPrint(players.get(player).getName());	
		distributePoints(players.get(player));		
		nextRoundSetup();										
	}
	
	public void war() {
	}

	public void nextRoundSetup() {
	}
	
	public void roundWinner() {		
	}
	
	public void distributePoints(Player player) {
	}
	
	public Player getWinner() {
		return Winner;
	}
	
	public void setWinner(Player player) {
		Winner = player;
	}
}