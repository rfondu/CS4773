package game;

import java.util.ArrayList;

import deck.Card;
import player.Player;
import player.PlayerPoints;
import warGame.Output;

/**
 * This class implements the InterfaceGameType. This class is for a three player
 * war game. 
 * 
 */
public class ThreePlayer implements InterfaceGameType{
	ArrayList<Card> inPlay = new ArrayList<Card>(); 
	ArrayList<Player> players;
	Player winner = null;
	private int gameType;
	
	/**
	 * Start round of play for list of players.
	 * 
	 * @param players    Array list of players
	 *        gameType   Game type is passed 
	 */
	public void startRound (ArrayList<Player> players, int gameType) {
		this.players = players;
		playCards();	
	}
	/**
	 * Get cards in deck to play hand for each player.
	 */
	public void playCards() {
		if(players.get(0).getDownPile().size() == 0) {
			roundWinner();
			return;
		}
		inPlay.add(players.get(0).drawCard());     			// Player 1 draws a card
		inPlay.add(players.get(1).drawCard());				// Player 2 draws a card
		inPlay.add(players.get(2).drawCard());				// Player 2 draws a card
		Output.playedCardPrint(players, inPlay); 	
		compareCards();										
	}
	/**
	 * Compare the cards drawn for each player
	 */
	public void compareCards() {
		int numberCardPlayed = inPlay.size(); 				
		if(inPlay.get(numberCardPlayed - 3).getValue().getCardValue() > inPlay.get(numberCardPlayed - 2).getValue().getCardValue()) {
			if(inPlay.get(numberCardPlayed - 3).getValue().getCardValue() > inPlay.get(numberCardPlayed - 1).getValue().getCardValue()) {
				endRound(0);
			}else if(inPlay.get(numberCardPlayed - 3).getValue().getCardValue() < inPlay.get(numberCardPlayed - 1).getValue().getCardValue()) {
				endRound(2);
			} else
				war();
		}else if(inPlay.get(numberCardPlayed - 2).getValue().getCardValue() > inPlay.get(numberCardPlayed - 1).getValue().getCardValue()) {
			if(inPlay.get(numberCardPlayed - 2).getValue().getCardValue() > inPlay.get(numberCardPlayed - 3).getValue().getCardValue()) {
				endRound(1);
			} else
				war();
		} else if(inPlay.get(numberCardPlayed - 2).getValue().getCardValue() < inPlay.get(numberCardPlayed - 1).getValue().getCardValue())
			endRound(2);
		else 
			war();
	}
	/**
	 * When war occurs need to get next card for each player to "place" face down then continue play.
	 */
	public void war() {
		Output.warPrint();						
		if(players.get(0).getDownPile().size() == 0) {
			Output.printScoreAllPlayers(players,gameType);
			roundWinner();
			return;
		}
		inPlay.add(players.get(0).drawCard());			// Player 1 draws a card
		inPlay.add(players.get(1).drawCard());			// Player 2 draws a card
		inPlay.add(players.get(2).drawCard());			// Player 3 draws a card
		playCards();									
	}
	/**
	 * End round of play. Add points to player based on index in parameter.
	 * 
	 * @param player Index of player that won the round
	 */
	public void endRound(int player) {
		Output.roundWinnerPrint(players.get(player).getName());	
		((PlayerPoints)(players.get(player))).setPoints(inPlay.size());		   
		nextRoundSetup(); 
		return;
	}
	/**
	 * Set up for next round of play.
	 */
	public void nextRoundSetup() {
		inPlay.clear();
		Output.printScoreAllPlayers(players,gameType);
		playCards();
	}
	/**
	 * Determine winner of a round.
	 */
	public void roundWinner() {
		if(((PlayerPoints)players.get(0)).getPoints() > ((PlayerPoints)players.get(1)).getPoints()) {
			if(((PlayerPoints)players.get(0)).getPoints() > ((PlayerPoints)players.get(2)).getPoints()) {
				declareWinner(0);
			}else if(((PlayerPoints)players.get(0)).getPoints() == ((PlayerPoints)players.get(2)).getPoints()){
				Output.tieGamePrint();
			}else {
				declareWinner(2);
			}
		}else if(((PlayerPoints)players.get(0)).getPoints() == ((PlayerPoints)players.get(1)).getPoints()){
			if(((PlayerPoints)players.get(0)).getPoints() > ((PlayerPoints)players.get(2)).getPoints()) {
				Output.tieGamePrint();
			}else {
				declareWinner(2);
			}
		}else if (((PlayerPoints)players.get(1)).getPoints() > ((PlayerPoints)players.get(2)).getPoints()){
			declareWinner(1);
		}else if (((PlayerPoints)players.get(1)).getPoints() == ((PlayerPoints)players.get(2)).getPoints()){
			Output.tieGamePrint();
		}else {
			declareWinner(2);
		}
	}
	/**
	 * Winner declaration procedure.
	 * 
	 * @param player Index of player that won
	 */
	public void declareWinner(int player) {
		Output.gameWinnerPrint(players.get(player).getName());
		setWinner(players.get(player));
	}
	@Override
	public Player getWinner() {
		return winner;
	}
	@Override
	public void setWinner(Player player) {
		winner = player;
	}
}