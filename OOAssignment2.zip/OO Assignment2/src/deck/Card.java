package deck;

public class Card{
	
	private VALUE value;
	private SUIT suit;
	
	/**
	 * Entry point for program
	 * 
	 * @param args command-line arguments
	 */
	
	public Card (VALUE value, SUIT suit) {
			this.value = value;
			this.suit = suit;
	}
	
	public SUIT getSuit(){
		return suit;
	}
	 
	public void setSuit(SUIT suit){
		this.suit = suit;
	}
	 
	public VALUE getValue() {
		return value;
	}
	 
	public void setValue(VALUE value){
		this.value = value;
	}
	
}