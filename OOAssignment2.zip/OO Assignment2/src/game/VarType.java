package game;

public class VarType {

}
