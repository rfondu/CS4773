package deck;

import java.util.ArrayList;
import java.util.Collections;

import player.Player;

public class Deck {
	
	private ArrayList<Card> deck = new ArrayList<Card>();
	
	public Deck() {
		deck = new ArrayList<Card>();
	}
	
	public void distributeCardsAmongPlayers(Deck deck, ArrayList<Player> players) {
		int split = deck.getDeck().size() / players.size();
		for(int j = 0; j < players.size(); j++) {
			for(int i = 0; i < split; i++) {
				Card card = deck.getDeck().remove(0);
				players.get(j).addCard(card);
			}
		}
	}
	
	public void fiftyTwoCardDeck(){
		for(SUIT suit: SUIT.values()) {
			for(VALUE value: VALUE.values()) {
				addCardToDeck(new Card(value, suit));				
			}
		}
	}

	public void addCardToDeck(Card card) {	
		deck.add(card);
	}

	public void shuffleDeck() {
		Collections.shuffle(deck);
	}
	
	public ArrayList<Card> getDeck() {
		return deck;
	}
}