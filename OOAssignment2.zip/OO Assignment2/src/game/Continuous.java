package game;

import player.Player;
import player.PlayerContinuous;
import warGame.Output;

/**
 * This class extends the TwoPlayer class. It's for the game variation 1 where
 * the cards played are added to the winners hand and play ends at a set # of iterations.
 * 
 */
public class Continuous extends TwoPlayer{
	int iterations = 20;
	int currentRound = 0;
	
	/**
	 * Add cards to down pile for player passed in .
	 * 
	 * @param player Player object
	 */
	@Override
	public void distributePoints(Player player) {
		((PlayerContinuous)player).addToDownPile(inPlay);
	}
	/**
	 * Set up for next round of play.
	 */
	@Override
	public void nextRoundSetup() {
		inPlay.clear();
		Output.printScoreAllPlayers(players,gameType);
		playCards();
	}
	/**
	  * When war occurs need to get next card for each player to "place" face down then continue play..
	 */
	@Override
	public void war() {
		Output.warPrint();						
		if(currentRound == iterations || players.get(0).getDownPile().size() == 0 || players.get(1).getDownPile().size() == 0 ) {
			Output.printScoreAllPlayers(players,gameType);
			roundWinner();
			return;
		}
		inPlay.add(players.get(0).drawCard());			// Player 1 draws a card
		inPlay.add(players.get(1).drawCard());			// Player 2 draws a card
		playCards();									
	}
	/**
	 * Get cards in deck to play hand for each player.
	 */
	@Override
	public void playCards() {
		//check downPile for each player
		if(currentRound < iterations) {
			if(players.get(0).getDownPile().size() == 0 || players.get(1).getDownPile().size() == 0 ) {
				//call EndGame
				roundWinner();
				return;
			}
			inPlay.add(players.get(0).drawCard());     			// Player 1 draws a card
			inPlay.add(players.get(1).drawCard());				// Player 2 draws a card
			Output.playedCardPrint(players, inPlay); 	
			currentRound++;
			compareCards();										
		}else {
			roundWinner();
		}
	}
	/**
	 * Determine winner of a round.
	 */
	@Override
	public void roundWinner() {
		if(players.get(0).getDownPile().size() == players.get(1).getDownPile().size()) {
			Output.tieGamePrint();
		}else if(players.get(0).getDownPile().size() > players.get(1).getDownPile().size()) {
			Output.gameWinnerPrint(players.get(0).getName());
			setWinner(players.get(0));
		}else {
			Output.gameWinnerPrint(players.get(1).getName());
			setWinner(players.get(1));
		}	
	}
}