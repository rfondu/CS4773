package game;

import player.Player;
import player.PlayerPoints;
import warGame.Output;

/**
 * This class extends the TwoPlayer class. It's for the game variation 2 & 3 where
 * the played cards are put into a pile for each player and totaled up when all
 * cards are played.  Player with most cards wins or if equal then there's a tie.
 */
public class Points extends TwoPlayer{
	
	/**
	 * Sets the points for the player passed from the in play pile of cards.
	 * 
	 * @param player Player object
	 */
	@Override
	public void distributePoints(Player player) {
		((PlayerPoints)player).setPoints(inPlay.size());
	}
	/**
	 * Set up for next round of play.
	 */
	@Override
	public void nextRoundSetup() {
		inPlay.clear();
		Output.printScoreAllPlayers(players,gameType);
		playCards();
	}
	/**
	 * Determine winner of a round.
	 */
	@Override
	public void roundWinner() {
		if(((PlayerPoints)players.get(0)).getPoints() == ((PlayerPoints)players.get(1)).getPoints()) {
			Output.tieGamePrint();
		}else if(((PlayerPoints)players.get(0)).getPoints() > ((PlayerPoints)players.get(1)).getPoints()) {
			Output.gameWinnerPrint(players.get(0).getName());
			setWinner(players.get(0));
		}else {
			Output.gameWinnerPrint(players.get(1).getName());
			setWinner(players.get(1));
		}
	}
	/**
	 * When war occurs need to get next card for each player to "place" face down then continue play.
	 */
	@Override
	public void war() {
		Output.warPrint();						
		if(players.get(0).getDownPile().size() == 0) {
			Output.printScoreAllPlayers(players,gameType);
			roundWinner();
			return;
		}
		inPlay.add(players.get(0).drawCard());			// Player 1 draws a card
		inPlay.add(players.get(1).drawCard());			// Player 2 draws a card
		playCards();									
	}
}